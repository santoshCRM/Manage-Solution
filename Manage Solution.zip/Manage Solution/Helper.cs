﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.IO;
using System.Xml;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.Drawing;
using Microsoft.Xrm.Tooling.Connector;
using System.Net;
using System.Windows.Forms;

namespace CloneSolution
{
    public static class Helper
    {
        #region variable used
        private static ExportSolutionRequest _exportRequest;

        public static ExportSolutionRequest ExportRequest
        {
            get { return Helper._exportRequest; }
            set { Helper._exportRequest = value; }
        }
        private static string _outputDir;

        public static string OutputDir
        {
            get { return Helper._outputDir; }
            set { Helper._outputDir = value; }
        }

        private static bool _isManaged;

        public static bool IsManaged
        {
            get { return Helper._isManaged; }
            set { Helper._isManaged = value; }
        }
        private static bool _isunManaged;

        public static bool IsunManaged
        {
            get { return Helper._isunManaged; }
            set { Helper._isunManaged = value; }
        }

        private static DataGridViewRow _selectedRow;

        public static DataGridViewRow SelectedRow
        {
            get { return Helper._selectedRow; }
            set { Helper._selectedRow = value; }
        }
        private static List<SolutionClass> _SolutionClasses;
        internal static List<SolutionClass> SolutionClasses
        {
            get { return Helper._SolutionClasses; }
            set { Helper._SolutionClasses = value; }
        }
        private static OrganizationServiceProxy _serviceProxy;
        public static OrganizationServiceProxy ServiceProxy
        {
            get { return Helper._serviceProxy; }
            set { Helper._serviceProxy = value; }
        }
        private static string _OrganizationUri;
        public static string OrganizationUri
        {
            get { return Helper._OrganizationUri; }
            set { Helper._OrganizationUri = value; }
        }
        private static ClientCredentials _Credentials = null;
        public static ClientCredentials Credentials
        {
            get { return Helper._Credentials; }
            set { Helper._Credentials = value; }
        }
        #endregion

        internal static void createConn(IOrganizationService Service)
        {

            _serviceProxy = (OrganizationServiceProxy)Service;

        }
        internal static string CreateXml(string xml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);

            // Load document
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }
        internal static string CreateXml(XmlDocument doc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }

            XmlAttribute pageAttr = doc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);

            XmlAttribute countAttr = doc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            doc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }
        internal static void CloneSolution(string targetSolutionuniquename, string newSolution)
        {
            // Retrieve a solution
            QueryExpression querySampleSolution = new QueryExpression
            {

                EntityName = "solution",
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression()
            };

            querySampleSolution.Criteria.AddCondition("uniquename", ConditionOperator.Equal, targetSolutionuniquename);
            Entity SampleSolution = (Entity)_serviceProxy.RetrieveMultiple(querySampleSolution).Entities[0];
            // Retrieve Solution componenet
            // get solution components for solution unique name
            QueryExpression componentsQuery = new QueryExpression
            {
                EntityName = "solutioncomponent",
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression(),
            };
            LinkEntity solutionLink = new LinkEntity("solutioncomponent", "solution", "solutionid", "solutionid", JoinOperator.Inner);
            solutionLink.LinkCriteria = new FilterExpression();
            solutionLink.LinkCriteria.AddCondition(new ConditionExpression("uniquename", ConditionOperator.Equal, targetSolutionuniquename));
            componentsQuery.LinkEntities.Add(solutionLink);
            EntityCollection ComponentsResult = _serviceProxy.RetrieveMultiple(componentsQuery);
            EntityReference publisher = (EntityReference)(SampleSolution.Attributes["publisherid"]);
            // Check Publisher isreadonly
            Entity PublisherCheck = _serviceProxy.Retrieve(publisher.LogicalName, publisher.Id, new ColumnSet(true));
            if (PublisherCheck != null)
                if ((bool)PublisherCheck.Attributes["isreadonly"])
                {
                    //select default publisher
                    //The default publisher has a constant GUID value;
                    Guid DefaultPublisherId = new Guid("{d21aab71-79e7-11dd-8874-00188b01e34f}");
                    publisher = new EntityReference("publisher", DefaultPublisherId);
                }
                else
                {
                    //no code
                }

            // Create a Solution
            Entity solution = new Entity("solution");
            solution.Attributes.Add("uniquename", newSolution);
            solution.Attributes.Add("friendlyname", newSolution);
            solution.Attributes.Add("publisherid", publisher);
            if (SampleSolution.Attributes.Contains("description"))
            if (!string.IsNullOrEmpty(SampleSolution.Attributes["description"].ToString()))
                solution.Attributes.Add("description", SampleSolution.Attributes["description"]);
            solution.Attributes.Add("version", SampleSolution.Attributes["version"]);
            Guid _solutionsSampleSolutionId = _serviceProxy.Create(solution);


            foreach (Entity component in ComponentsResult.Entities)
            {
                AddSolutionComponentRequest addReq = new AddSolutionComponentRequest()
                {
                    ComponentType = ((Microsoft.Xrm.Sdk.OptionSetValue)(component.Attributes["componenttype"])).Value,
                    ComponentId = (Guid)component.Attributes["objectid"],
                    SolutionUniqueName = newSolution
                };
                try
                {
                    _serviceProxy.Execute(addReq);
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(ex.InnerException.ToString());
                }


            }
        }
        internal static bool ValidateSolutions(string newSolution)
        {
            // Retrieve a solution
            QueryExpression querySampleSolution = new QueryExpression
            {

                EntityName = "solution",
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression()
            };

            querySampleSolution.Criteria.AddCondition("uniquename", ConditionOperator.Equal, newSolution);
            if (_serviceProxy.RetrieveMultiple(querySampleSolution).Entities.Count > 0)
                return false;
            else
                return true;
        }
        internal static void getSolutions()
        {
            // Retrieve  solution
            SolutionClasses = new List<SolutionClass>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='solution' >" +
"  <attribute name='isvisible' />" +
"    <attribute name='ismanagedname' />" +
"    <attribute name='friendlyname' />" +
"    <attribute name='parentsolutionid' />" +
"    <attribute name='publisherid' />" +
"    <attribute name='configurationpageid' />" +
"    <attribute name='organizationid' />" +
"    <attribute name='solutionpackageversion' />" +
"    <attribute name='solutiontype' />" +
"    <attribute name='configurationpageidname' />" +
"    <attribute name='version' />" +
"    <attribute name='versionnumber' />" +
"    <attribute name='publisheridprefix' />" +
"    <attribute name='ismanaged' />" +
"    <attribute name='organizationidname' />" +
"    <attribute name='solutionid' />" +
"    <attribute name='uniquename' />" +
"    <attribute name='description' />" +
"    <attribute name='publisheridname' />" +
"    <attribute name='publisheridoptionvalueprefix' />" +
"  </entity>" +
"</fetch>";


            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                EntityCollection returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;

                foreach (Entity ent in returnCollection.Entities)
                {
                    SolutionClass Solution = new SolutionClass();
                    if (ent.Attributes.Contains("isvisible"))
                    Solution.Isvisible = ent.Attributes["isvisible"].ToString();
                    if (ent.Attributes.Contains("friendlyname"))
                    Solution.Friendlyname = ent.Attributes["friendlyname"].ToString();
                    if (ent.Attributes.Contains("publisherid"))
                    Solution.Publisher = ((Microsoft.Xrm.Sdk.EntityReference)(ent.Attributes["publisherid"])).Name;
                    if (ent.Attributes.Contains("organizationid"))
                    Solution.Organization = ((Microsoft.Xrm.Sdk.EntityReference)(ent.Attributes["organizationid"])).Name;
                    if(ent.Attributes.Contains("solutionpackageversion"))
                    Solution.Solutionpackageversion = ent.Attributes["solutionpackageversion"].ToString();
                    if (ent.Attributes.Contains("solutiontype"))
                    Solution.Solutiontype = ((Microsoft.Xrm.Sdk.OptionSetValue)(ent.Attributes["solutiontype"])).Value.ToString();
                    if (ent.Attributes.Contains("version"))
                    Solution.Version = ent.Attributes["version"].ToString();
                    if (ent.Attributes.Contains("versionnumber"))
                    Solution.Versionnumber = ent.Attributes["versionnumber"].ToString();
                    if (ent.Attributes.Contains("ismanaged"))
                    Solution.Ismanaged = ent.Attributes["ismanaged"].ToString();
                    if (ent.Attributes.Contains("solutionid"))
                    Solution.Solution = ent.Attributes["solutionid"].ToString();
                    if (ent.Attributes.Contains("uniquename"))
                    Solution.Uniquename = ent.Attributes["uniquename"].ToString();
                    if (ent.Attributes.Contains("description"))
                    Solution.Description = ent.Attributes["description"].ToString();
                    SolutionClasses.Add(Solution);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


           

        }

        internal static void deleteSolution(Guid solutionId)
        {

            _serviceProxy.Delete("solution", solutionId);
        }
        internal static void PublishAll()
        {

            PublishAllXmlRequest publishReq = new PublishAllXmlRequest();
            _serviceProxy.Execute(publishReq);
        }
        internal static string getTargetVersion()
        {

            RetrieveVersionRequest retrieveVersionRequest = new RetrieveVersionRequest();
            RetrieveVersionResponse retrieveVersionResponse = (RetrieveVersionResponse)_serviceProxy.Execute(retrieveVersionRequest);
            return retrieveVersionResponse.Version;
        }
        internal static void ProcessExporting( )
        {
            string Version = ((string)Helper.SelectedRow.Cells["Version"].Value);
            bool flag = IsManaged & IsunManaged;
            if (flag)
            {
                ExportRequest.Managed=true;
                ExportSolution(ExportRequest, Version, OutputDir);
                ExportRequest.Managed = false;
                ExportSolution(ExportRequest, Version, OutputDir);
            }
            else
            {
                bool flag2 = !IsManaged & IsunManaged;
                if (flag2)
                {
                    ExportRequest.Managed = false;
                    ExportSolution(ExportRequest, Version, OutputDir);
                }
                else
                {
                    bool flag3 = IsManaged && !IsunManaged;
                    if (flag3)
                    {
                        ExportRequest.Managed = true;
                        ExportSolution(ExportRequest, Version, OutputDir);
                    }
                }
            }
        }
        public static void ExportSolution( ExportSolutionRequest exportSolutionRequest, string version, string outputDir)
        {
            outputDir += "\\";
            try
            {
                ExportSolutionResponse exportSolutionResponse = (ExportSolutionResponse)_serviceProxy.Execute(exportSolutionRequest);
                byte[] exportSolutionFile = exportSolutionResponse.ExportSolutionFile;
                bool managed = exportSolutionRequest.Managed;
                string str;
                if (managed)
                {
                    str = exportSolutionRequest.SolutionName + "_" + version + "_managed.zip";
                }
                else
                {
                    str = exportSolutionRequest.SolutionName + "_" + version + ".zip";
                }
                File.WriteAllBytes(outputDir + str, exportSolutionFile);
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }
            
        }
    }
}
