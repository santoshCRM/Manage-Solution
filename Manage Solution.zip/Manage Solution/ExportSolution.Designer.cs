﻿namespace CloneSolution
{
    partial class ExportSolution
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.drp_targetSol = new System.Windows.Forms.ComboBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.chk_unmanage = new System.Windows.Forms.CheckBox();
            this.chk_manage = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chkgrp_exportSetting = new System.Windows.Forms.CheckedListBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btn_export = new System.Windows.Forms.ToolStripButton();
            this.folderdlg = new System.Windows.Forms.FolderBrowserDialog();
            this.txt_browse = new System.Windows.Forms.TextBox();
            this.btn_browse = new System.Windows.Forms.Button();
            this.lbl_browse = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(281, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Target Version";
            // 
            // drp_targetSol
            // 
            this.drp_targetSol.FormattingEnabled = true;
            this.drp_targetSol.Location = new System.Drawing.Point(284, 135);
            this.drp_targetSol.Name = "drp_targetSol";
            this.drp_targetSol.Size = new System.Drawing.Size(178, 21);
            this.drp_targetSol.TabIndex = 2;
            // 
            // chk_unmanage
            // 
            this.chk_unmanage.AutoSize = true;
            this.chk_unmanage.Location = new System.Drawing.Point(284, 44);
            this.chk_unmanage.Name = "chk_unmanage";
            this.chk_unmanage.Size = new System.Drawing.Size(85, 17);
            this.chk_unmanage.TabIndex = 3;
            this.chk_unmanage.Text = "UnManaged";
            this.chk_unmanage.UseVisualStyleBackColor = true;
            // 
            // chk_manage
            // 
            this.chk_manage.AutoSize = true;
            this.chk_manage.Location = new System.Drawing.Point(284, 79);
            this.chk_manage.Name = "chk_manage";
            this.chk_manage.Size = new System.Drawing.Size(71, 17);
            this.chk_manage.TabIndex = 4;
            this.chk_manage.Text = "Managed";
            this.chk_manage.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_browse);
            this.groupBox1.Controls.Add(this.btn_browse);
            this.groupBox1.Controls.Add(this.txt_browse);
            this.groupBox1.Controls.Add(this.chkgrp_exportSetting);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.chk_manage);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.chk_unmanage);
            this.groupBox1.Controls.Add(this.drp_targetSol);
            this.groupBox1.Location = new System.Drawing.Point(12, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(485, 277);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Export settings";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(281, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Package Type:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Export System Settings (Advanced)";
            // 
            // chkgrp_exportSetting
            // 
            this.chkgrp_exportSetting.FormattingEnabled = true;
            this.chkgrp_exportSetting.Items.AddRange(new object[] {
            "Auto-numbering",
            "Calendar",
            "Customization",
            "Email tracking",
            "General",
            "Marketing",
            "Outlook Synchronization",
            "Relationship Roles",
            "ISV Config",
            "Sales"});
            this.chkgrp_exportSetting.Location = new System.Drawing.Point(19, 44);
            this.chkgrp_exportSetting.Name = "chkgrp_exportSetting";
            this.chkgrp_exportSetting.Size = new System.Drawing.Size(210, 154);
            this.chkgrp_exportSetting.TabIndex = 7;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btn_export});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(509, 25);
            this.toolStrip1.TabIndex = 6;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btn_export
            // 
            this.btn_export.Image = global::CloneSolution.Properties.Resources.export;
            this.btn_export.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(60, 22);
            this.btn_export.Text = "Export";
            this.btn_export.Click += new System.EventHandler(this.btn_export_Click);
            // 
            // txt_browse
            // 
            this.txt_browse.Location = new System.Drawing.Point(99, 225);
            this.txt_browse.Name = "txt_browse";
            this.txt_browse.Size = new System.Drawing.Size(275, 20);
            this.txt_browse.TabIndex = 8;
            // 
            // btn_browse
            // 
            this.btn_browse.Location = new System.Drawing.Point(387, 222);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(75, 23);
            this.btn_browse.TabIndex = 9;
            this.btn_browse.Text = "Browse...";
            this.btn_browse.UseVisualStyleBackColor = true;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            // 
            // lbl_browse
            // 
            this.lbl_browse.AutoSize = true;
            this.lbl_browse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_browse.Location = new System.Drawing.Point(19, 225);
            this.lbl_browse.Name = "lbl_browse";
            this.lbl_browse.Size = new System.Drawing.Size(60, 13);
            this.lbl_browse.TabIndex = 10;
            this.lbl_browse.Text = "Location:";
            // 
            // ExportSolution
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(509, 325);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ExportSolution";
            this.Text = "ExportSolution";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox drp_targetSol;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.CheckBox chk_unmanage;
        private System.Windows.Forms.CheckBox chk_manage;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckedListBox chkgrp_exportSetting;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btn_export;
        private System.Windows.Forms.FolderBrowserDialog folderdlg;
        private System.Windows.Forms.Label lbl_browse;
        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.TextBox txt_browse;
    }
}