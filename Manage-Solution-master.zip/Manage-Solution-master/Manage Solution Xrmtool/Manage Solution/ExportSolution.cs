﻿using Microsoft.Crm.Sdk.Messages;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CloneSolution
{
    public partial class ExportSolution : Form
    {
        string version;
        public ExportSolution()
        {
            InitializeComponent();
            this.drp_targetSol.DropDownStyle = ComboBoxStyle.DropDownList;
            this.folderdlg = new System.Windows.Forms.FolderBrowserDialog();
            SetTargets();
        }
        private void SetTargets()
        {
            version = Helper.getTargetVersion();
            switch (Version(this.version))
            {
                case "8.0":
                    this.drp_targetSol.Items.AddRange(Constants.targets80);
                    break;
                case "8.1":
                    this.drp_targetSol.Items.AddRange(Constants.targets81);
                    break;
                case "8.2":
                    this.drp_targetSol.Items.AddRange(Constants.targets82);
                    break;
                case "9.0":
                    this.drp_targetSol.Items.AddRange(Constants.targets90);
                    break;
                case "9.1":
                    this.drp_targetSol.Items.AddRange(Constants.targets91);
                    this.drp_targetSol.SelectedIndex = 0;
                    break;
                case "9.2":
                    this.drp_targetSol.Items.AddRange(Constants.targets92);
                    this.drp_targetSol.SelectedIndex = 0;
                    break;
                default:
                    MessageBox.Show("This Plugin support from 8.0 to 9.2 Version");
                    break;

            }

        }
        public static string Version(string number)
        {
            string[] array = number.Split(new char[]
	{
		'.'
	});
            return array[0] + "." + array[1];
        }
        private void btn_export_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txt_browse.Text))
            {
                if (chk_unmanage.Checked != true && chk_manage.Checked != true)
                {
                    MessageBox.Show("Select package type.");
                }
                else
                {
                    if(drp_targetSol.SelectedIndex<0)
                    {
                        MessageBox.Show("Select target version");
                    }
                    else
                    {
                        bool flag2 = !Directory.Exists(this.txt_browse.Text);
                        if (flag2)
                        {
                            MessageBox.Show("Please fill in  correctly the output directory");
                        }
                        else
                        {
                           
                            string text = this.drp_targetSol.SelectedItem.ToString();
                            Helper.IsManaged = this.chk_manage.Checked;
                            Helper.IsunManaged = this.chk_unmanage.Checked;
                            Helper.OutputDir = this.txt_browse.Text;
                            Helper.ExportRequest = ExportSolutionMapping();
                         
                            if (!String.IsNullOrEmpty(Helper.MyMessage))
                            {
                                MessageBox.Show(Helper.MyMessage);
                                Helper.MyMessage = "";
                            }
                            
                            this.Close();
                        }
                        
                    }
                    
                }
            }
            else
                MessageBox.Show("Select folder location.");

          
        }
        private ExportSolutionRequest ExportSolutionMapping()
        {
            string targetVersion = drp_targetSol.SelectedItem.ToString();
            ExportSolutionRequest exportSolutionRequest = new ExportSolutionRequest();
            exportSolutionRequest.SolutionName = ((string)Helper.SelectedRow.Cells["Uniquename"].Value);
            if (targetVersion != "9.1")
                exportSolutionRequest.TargetVersion = targetVersion;
            bool flag = this.chkgrp_exportSetting.CheckedItems.Count != 0;
            if (flag)
            {
                for (int i = 0; i <= this.chkgrp_exportSetting.CheckedItems.Count - 1; i++)
                {
                    string obj = this.chkgrp_exportSetting.CheckedItems[i].ToString();
                    exportSolutionRequest.ExportAutoNumberingSettings=this.chkgrp_exportSetting.Items[0].Equals(obj);
                    exportSolutionRequest.ExportCalendarSettings=this.chkgrp_exportSetting.Items[1].Equals(obj);
                    exportSolutionRequest.ExportCustomizationSettings=this.chkgrp_exportSetting.Items[2].Equals(obj);
                    exportSolutionRequest.ExportEmailTrackingSettings=this.chkgrp_exportSetting.Items[3].Equals(obj);
                    exportSolutionRequest.ExportGeneralSettings=this.chkgrp_exportSetting.Items[4].Equals(obj);
                    exportSolutionRequest.ExportMarketingSettings = this.chkgrp_exportSetting.Items[5].Equals(obj);
                    exportSolutionRequest.ExportOutlookSynchronizationSettings = this.chkgrp_exportSetting.Items[6].Equals(obj);
                    exportSolutionRequest.ExportRelationshipRoles = this.chkgrp_exportSetting.Items[7].Equals(obj);
                    exportSolutionRequest.ExportIsvConfig = this.chkgrp_exportSetting.Items[8].Equals(obj);
                    exportSolutionRequest.ExportSales = this.chkgrp_exportSetting.Items[9].Equals(obj);
                }
            }
            return exportSolutionRequest;
        }
        private void btn_browse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;
            // Show the FolderBrowserDialog.
            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                txt_browse.Text = folderDlg.SelectedPath;
                Environment.SpecialFolder root = folderDlg.RootFolder;

            }
        }
    }
}
