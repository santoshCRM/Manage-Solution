﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloneSolution
{
    internal class SolutionClass
    {
        private string _isvisible;

        public string Isvisible
        {
            get { return _isvisible; }
            set { _isvisible = value; }
        }
      
        private string _friendlyname;

        public string Friendlyname
        {
            get { return _friendlyname; }
            set { _friendlyname = value; }
        }
        
        private string _publisher;

        public string Publisher
        {
            get { return _publisher; }
            set { _publisher = value; }
        }
       
        private string _organization;

        public string Organization
        {
            get { return _organization; }
            set { _organization = value; }
        }
        private string _solutionpackageversion;

        public string Solutionpackageversion
        {
            get { return _solutionpackageversion; }
            set { _solutionpackageversion = value; }
        }
        private string _solutiontype;

        public string Solutiontype
        {
            get { return _solutiontype; }
            set { _solutiontype = value; }
        }
       

        private string _version;

        public string Version
        {
            get { return _version; }
            set { _version = value; }
        }
        private string _versionnumber;

        public string Versionnumber
        {
            get { return _versionnumber; }
            set { _versionnumber = value; }
        }
      
        private string _ismanaged;

        public string Ismanaged
        {
            get { return _ismanaged; }
            set { _ismanaged = value; }
        }
       
        
        private string _uniquename;

        public string Uniquename
        {
            get { return _uniquename; }
            set { _uniquename = value; }
        }
        private string _description;

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        private string _solution;

        public string Solution
        {
            get { return _solution; }
            set { _solution = value; }
        }

    }
}
