﻿using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using XrmToolBox.Extensibility;

namespace CloneSolution
{
    public partial class CloneSolution : PluginControlBase
    {
        #region constructor
        public CloneSolution()
        {
            InitializeComponent();
           
        }
      
        #endregion
        #region Retrieve Solutions
        private void btn_retSol_Click(object sender, EventArgs e)
        {
            Helper.createConn(Service);
            ExecuteMethod(GetSolutions);
        }
        void GetSolutions()
        {
            WorkAsync(new WorkAsyncInfo
            {
                Message = "Retrieving solutions...",
                Work = (bw, m) =>
                {

                    if (base.Service != null)
                    {
                        grdview_solutions.DataSource = null;
                        Helper.getSolutions();
                        grdview_solutions.DataSource = Helper.SolutionClasses;
                    }
                },
                PostWorkCallBack = m =>
                {
                    if (m.Error == null)
                    {

                    }
                    else
                    {
                        MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            });
        }
        #endregion
        #region Search solution
        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txt_search.Text))
                grdview_solutions.DataSource = Helper.SolutionClasses.Where(x => x.Friendlyname.ToLower().Contains(txt_search.Text.ToLower())).ToList();
            else
                grdview_solutions.DataSource = Helper.SolutionClasses;
        }
        #endregion
        #region Make a copy of solution
        private void btn_cloneSolution_Click(object sender, EventArgs e)
        {
            if (grdview_solutions.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = grdview_solutions.SelectedRows[0];
                if (!string.IsNullOrEmpty(txt_clonesolution.Text))
                {
                    if (Helper.ValidateSolutions(txt_clonesolution.Text))
                    {
                        Helper.createConn(Service);
                        if (Service != null)
                        {
                            WorkAsync(new WorkAsyncInfo
                            {
                                Message = "Creating Copy of Solution- " + selectedRow.Cells[1].Value.ToString(),
                                Work = (bw, m) =>
                                {
                                    Helper.CloneSolution(selectedRow.Cells[9].Value.ToString(), txt_clonesolution.Text);
                                   
                                },
                                PostWorkCallBack = m =>
                                {
                                    if (m.Error == null)
                                    {
                                        MessageBox.Show("Copy of Solution- " + selectedRow.Cells[1].Value.ToString()+" Created");
                                        Helper.SolutionClasses.Clear();
                                        btn_retSol_Click(null, null);
                                        txt_search.Text = txt_clonesolution.Text;
                                    }
                                    else
                                    {
                                        MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                               MessageBoxIcon.Error);
                                    }
                                }
                            });
                        }
                      
                       
                    }
                    else
                    {
                        MessageBox.Show("Provide different name. This name allready exist");
                        txt_clonesolution.Focus();
                    }
                }
                else
                    MessageBox.Show("Provide New solution name!!");
            }
            else
            {
                MessageBox.Show("No Solution selected to clone");
            }

        }
        #endregion
        #region Delete Solution
        private void btn_delsol_Click(object sender, EventArgs e)
        {
            DeleteSolution();

        }

        private void DeleteSolution()
        {
            if (grdview_solutions.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = grdview_solutions.SelectedRows[0];
                var confirmResult = MessageBox.Show("Are you sure to delete this Solution- " + selectedRow.Cells[1].Value.ToString() + "??",
                                     "Confirm Delete!!",
                                     MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {
                   
                        WorkAsync(new WorkAsyncInfo
                        {
                            Message = "Deleting  Solution... " + selectedRow.Cells[1].Value.ToString(),
                            Work = (bw, m) =>
                            {
                                Helper.createConn(Service);
                                if (Service != null)
                                {
                                    Helper.deleteSolution(new Guid(selectedRow.Cells[11].Value.ToString()));
                                }
                            },
                            PostWorkCallBack = m =>
                            {
                                if (m.Error == null)
                                {
                                    MessageBox.Show("Solution deleted.");
                                    btn_retSol_Click(null, null);
                                }
                                else
                                {
                                    MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                           MessageBoxIcon.Error);
                                    btn_retSol_Click(null, null);
                                }
                            }
                        });
                    
                   
                }

            }
            else
            {
                MessageBox.Show("No Solution selected to clone");
            }
        }
        #endregion
        #region Publish All Customization
        private void btn_publishall_Click(object sender, EventArgs e)
        {
            PublishAllCustomization();

        }

        private void PublishAllCustomization()
        {
            Helper.createConn(Service);
            if (Service != null)
            {
                WorkAsync(new WorkAsyncInfo
                {
                    Message = "Please wait. We are publishing your all customization.",
                    Work = (bw, m) =>
                    {
                        Helper.PublishAll();
                    },
                    PostWorkCallBack = m =>
                    {
                        if (m.Error == null)
                        {

                        }
                        else
                        {
                            MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error);
                        }
                    }
                });
            }
        }
        #endregion
        #region Export Grid
        private void btn_exportGrid_Click(object sender, EventArgs e)
        {
            if (grdview_solutions.Rows.Count > 1)
            {
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                // creating new WorkBook within Excel application  
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                // creating new Excelsheet in workbook  
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                // see the excel sheet behind the program  
                app.Visible = true;
                // get the reference of first sheet. By default its name is Sheet1.  
                // store its reference to worksheet  
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                // changing the name of active sheet  
                worksheet.Name = "Solution";
                // storing header part in Excel  
                for (int i = 1; i < grdview_solutions.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = grdview_solutions.Columns[i - 1].HeaderText;

                }
                //Header Style
                Microsoft.Office.Interop.Excel.Style HeaderStyle = workbook.Styles.Add("HeaderStyle");
                HeaderStyle.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                HeaderStyle.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);
                Microsoft.Office.Interop.Excel.Range HrangeStyles = app.get_Range("A1", "L1");
                HrangeStyles.Style = "HeaderStyle";
                // storing Each row and column value to excel sheet  
                for (int i = 0; i < grdview_solutions.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < grdview_solutions.Columns.Count; j++)
                    {
                        if (grdview_solutions.Rows[i].Cells[j].ValueType.Name.ToString() == "String")
                        {
                            if (grdview_solutions.Rows[i].Cells[j].Value != null)
                                worksheet.Cells[i + 2, j + 1] = grdview_solutions.Rows[i].Cells[j].Value.ToString();
                        }


                    }
                }
                worksheet.Columns.AutoFit();
                // save the application 
                try
                {
                    workbook.SaveAs(saveExcel(), Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    // Exit from the application  
                    app.Quit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.InnerException.ToString());
                }
            }
            else
                MessageBox.Show("No record found to export");
        }
        internal object saveExcel()
        {

            SaveFileDialog sfd = new SaveFileDialog();// Create save the CSV
            sfd.Filter = "Text File|*.xls";// filters for text files only
            sfd.DefaultExt = "xls";
            sfd.AddExtension = true;
            sfd.FileName = "Solution.xls";
            sfd.Title = "Save Excel File";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                return sfd.FileName;
            }
            else
            {
                return null;
            }
        }
        #endregion
        #region Export Solution clicked
        private void btn_exportSol_Click(object sender, EventArgs e)
        {
            if (grdview_solutions.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = grdview_solutions.SelectedRows[0];
                if (Convert.ToBoolean(selectedRow.Cells[8].Value))
                {
                    MessageBox.Show("Please select a unmanaged solution or click on 'Make a copy' option then select and export unmanaged solution.");
                }
                else
                {
                    Helper.SelectedRow = selectedRow;
                    ExportSolution ExportSolution = new ExportSolution();
                    ExportSolution.StartPosition = FormStartPosition.CenterParent;
                    ExportSolution.ShowDialog();
                    ExportSolution.Dispose();
                  //  Helper.createConn(Service);
                    if (Service != null)
                    {
                        WorkAsync(new WorkAsyncInfo
                        {
                            Message = "Please wait. We are exporting solution -" + selectedRow.Cells[1].Value.ToString(),
                            Work = (bw, m) =>
                            {
                                Helper.ProcessExporting();
                                   
                            },
                            PostWorkCallBack = m =>
                            {
                                if (m.Error == null)
                                {
                                     MessageBox.Show("Solution exported");
                                }
                                else
                                {
                                    MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                           MessageBoxIcon.Error);
                                }
                            }
                        });
                    }
                  
                }

            }
            else
            {
                MessageBox.Show("No Solution selected to export");
            }
        }
        #endregion
        #region Close Plugin
        private void btn_close_Click(object sender, EventArgs e)
        {
            base.CloseTool();
        }
        #endregion
    }
}
