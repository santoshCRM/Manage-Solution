﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ManageSolution
{
    static class SampleProgram
    {
        [STAThread] // Added to support UX
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new CloneSolution());
        }

        //static void Main(string[] args)
        //{
        //    CrmServiceClient service = null;

        //    try
        //    {
        //        service = Helper.Connect("Connect");

        //        if (service.IsReady)
        //        {
        //            Guid userid = ((WhoAmIResponse)service.Execute(new WhoAmIRequest())).UserId;
        //            #region Sample Code
        //            ////////////////////////////////////
        //            #region Set up
        //            UserControl1 CloneSolutionFrm = new UserControl1();
        //            CloneSolutionFrm.Show();
        //            // SetUpSample(service);
        //            #endregion Set up

        //            #endregion Sample Code
        //        }
        //        else
        //        {
        //            const string UNABLE_TO_LOGIN_ERROR = "Unable to Login to Microsoft Dataverse";
        //            if (service.LastCrmError.Equals(UNABLE_TO_LOGIN_ERROR))
        //            {
        //                Console.WriteLine("Check the connection string values in cds/App.config.");
        //                throw new Exception(service.LastCrmError);
        //            }
        //            else
        //            {
        //                throw service.LastCrmException;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //       // SampleHelpers.HandleException(ex);
        //    }

        //    finally
        //    {
        //        if (service != null)
        //            service.Dispose();

        //        Console.WriteLine("Press <Enter> to exit.");
        //        Console.ReadLine();
        //    }
        //}
            }
}
