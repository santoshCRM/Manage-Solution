﻿namespace ManageSolution
{
    partial class CloneSolution
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_clonesolution = new System.Windows.Forms.TextBox();
            this.grdview_solutions = new System.Windows.Forms.DataGridView();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_Filter = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_close = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_retSol = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_cloneSolution = new System.Windows.Forms.ToolStripButton();
            this.btn_delsol = new System.Windows.Forms.ToolStripButton();
            this.btn_publishall = new System.Windows.Forms.ToolStripButton();
            this.btn_export = new System.Windows.Forms.ToolStripDropDownButton();
            this.btn_exportGrid = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_exportSol = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdview_solutions)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(18, 43);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1343, 707);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Size = new System.Drawing.Size(1335, 674);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Solutions";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.Controls.Add(this.txt_clonesolution);
            this.groupBox1.Controls.Add(this.grdview_solutions);
            this.groupBox1.Controls.Add(this.txt_search);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lb_Filter);
            this.groupBox1.Location = new System.Drawing.Point(10, 11);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(1228, 603);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // txt_clonesolution
            // 
            this.txt_clonesolution.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_clonesolution.Location = new System.Drawing.Point(824, 31);
            this.txt_clonesolution.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_clonesolution.Name = "txt_clonesolution";
            this.txt_clonesolution.Size = new System.Drawing.Size(305, 26);
            this.txt_clonesolution.TabIndex = 13;
            // 
            // grdview_solutions
            // 
            this.grdview_solutions.AllowUserToAddRows = false;
            this.grdview_solutions.AllowUserToDeleteRows = false;
            this.grdview_solutions.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grdview_solutions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdview_solutions.Location = new System.Drawing.Point(15, 71);
            this.grdview_solutions.Margin = new System.Windows.Forms.Padding(4, 5, 10, 10);
            this.grdview_solutions.MultiSelect = false;
            this.grdview_solutions.Name = "grdview_solutions";
            this.grdview_solutions.ReadOnly = true;
            this.grdview_solutions.RowHeadersWidth = 62;
            this.grdview_solutions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdview_solutions.Size = new System.Drawing.Size(1140, 470);
            this.grdview_solutions.TabIndex = 2;
            // 
            // txt_search
            // 
            this.txt_search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.txt_search.Location = new System.Drawing.Point(93, 31);
            this.txt_search.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(476, 26);
            this.txt_search.TabIndex = 1;
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(627, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Clone Solution Name";
            // 
            // lb_Filter
            // 
            this.lb_Filter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lb_Filter.AutoSize = true;
            this.lb_Filter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Filter.Location = new System.Drawing.Point(10, 31);
            this.lb_Filter.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_Filter.Name = "lb_Filter";
            this.lb_Filter.Size = new System.Drawing.Size(68, 20);
            this.lb_Filter.TabIndex = 0;
            this.lb_Filter.Text = "Search";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.btn_close,
            this.toolStripSeparator2,
            this.btn_retSol,
            this.toolStripSeparator3,
            this.btn_cloneSolution,
            this.btn_delsol,
            this.btn_publishall,
            this.btn_export});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.toolStrip1.Size = new System.Drawing.Size(1374, 34);
            this.toolStrip1.TabIndex = 11;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 34);
            // 
            // btn_close
            // 
            this.btn_close.Image = global::ManageSolution.Properties.Resources.tsbClose_Image;
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(83, 29);
            this.btn_close.Text = "Close";
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 34);
            // 
            // btn_retSol
            // 
            this.btn_retSol.Image = global::ManageSolution.Properties.Resources.tsbConnect_Image;
            this.btn_retSol.Name = "btn_retSol";
            this.btn_retSol.Size = new System.Drawing.Size(181, 29);
            this.btn_retSol.Text = "Retrieve Solutions";
            this.btn_retSol.Click += new System.EventHandler(this.btn_retSol_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 34);
            // 
            // btn_cloneSolution
            // 
            this.btn_cloneSolution.Image = global::ManageSolution.Properties.Resources.clonesolution;
            this.btn_cloneSolution.Name = "btn_cloneSolution";
            this.btn_cloneSolution.Size = new System.Drawing.Size(141, 29);
            this.btn_cloneSolution.Text = "Make a copy";
            this.btn_cloneSolution.Click += new System.EventHandler(this.btn_cloneSolution_Click);
            // 
            // btn_delsol
            // 
            this.btn_delsol.Image = global::ManageSolution.Properties.Resources.ico_16_delete;
            this.btn_delsol.Name = "btn_delsol";
            this.btn_delsol.Size = new System.Drawing.Size(161, 29);
            this.btn_delsol.Text = "Delete Solution";
            this.btn_delsol.Click += new System.EventHandler(this.btn_delsol_Click);
            // 
            // btn_publishall
            // 
            this.btn_publishall.Image = global::ManageSolution.Properties.Resources.publishall;
            this.btn_publishall.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_publishall.Name = "btn_publishall";
            this.btn_publishall.Size = new System.Drawing.Size(241, 29);
            this.btn_publishall.Text = "Publish All Customization";
            this.btn_publishall.Click += new System.EventHandler(this.btn_publishall_Click);
            // 
            // btn_export
            // 
            this.btn_export.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btn_exportGrid,
            this.btn_exportSol});
            this.btn_export.Image = global::ManageSolution.Properties.Resources.export;
            this.btn_export.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(105, 29);
            this.btn_export.Text = "Export";
            // 
            // btn_exportGrid
            // 
            this.btn_exportGrid.Name = "btn_exportGrid";
            this.btn_exportGrid.Size = new System.Drawing.Size(236, 34);
            this.btn_exportGrid.Text = "Export Grid";
            this.btn_exportGrid.Click += new System.EventHandler(this.btn_exportGrid_Click);
            // 
            // btn_exportSol
            // 
            this.btn_exportSol.Name = "btn_exportSol";
            this.btn_exportSol.Size = new System.Drawing.Size(236, 34);
            this.btn_exportSol.Text = "Export Solution";
            this.btn_exportSol.Click += new System.EventHandler(this.btn_exportSol_Click);
            // 
            // CloneSolution
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1374, 806);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "CloneSolution";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdview_solutions)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label lb_Filter;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btn_close;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btn_retSol;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.DataGridView grdview_solutions;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_clonesolution;
        private System.Windows.Forms.ToolStripButton btn_cloneSolution;
        private System.Windows.Forms.ToolStripButton btn_delsol;
        private System.Windows.Forms.ToolStripDropDownButton btn_export;
        private System.Windows.Forms.ToolStripMenuItem btn_exportGrid;
        private System.Windows.Forms.ToolStripMenuItem btn_exportSol;
        private System.Windows.Forms.ToolStripButton btn_publishall;
    }
}